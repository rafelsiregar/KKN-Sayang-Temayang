from django.apps import AppConfig


class DesajonoConfig(AppConfig):
    name = 'desajono'
