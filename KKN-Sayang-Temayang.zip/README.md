# KKN-Sayang-Temayang

Untuk mengembangkan web ini, gunakan framework berikut : 
- Bootstrap 5
- JQuery
- Django

Anda dapat menggunakan framework yang lain jika berkenan, khususnya untuk fungsionalitas (Javascript), namun disarankan untuk membuat folder sendiri.


Font dapat dilihat pada style.css, silahkan didownload fontnya dan disimpan di folder font di dalam FOLDER YANG SAMA dengan folder web ini.
